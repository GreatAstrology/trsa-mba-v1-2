# TRSA–MBA v1.2 — sito premium
Base web con pagina pubblica, formule, tabella operativa, area simulatore riservata e Stripe Checkout.
## Avvio
npm install
Impostare STRIPE_SECRET_KEY, STRIPE_PRICE_ID e PUBLIC_URL.
npm start
## Produzione
Prima di vendere l'accesso è necessario aggiungere autenticazione utenti, webhook Stripe e controllo server-side dei permessi premium.

## Video
La pagina pubblica include il video promozionale/scientifico:
`public/TRSA_MBA_v1_2_video_promozionale_scientifico.mp4`

Il video è integrato direttamente nella pagina tramite il player HTML5.
