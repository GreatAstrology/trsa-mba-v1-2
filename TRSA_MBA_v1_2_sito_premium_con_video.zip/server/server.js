const express=require("express");const path=require("path");const Stripe=require("stripe");
const app=express();const stripe=Stripe(process.env.STRIPE_SECRET_KEY);
app.use(express.json());app.use(express.static(path.join(__dirname,"..","public")));
app.post("/create-checkout-session",async(req,res)=>{try{const s=await stripe.checkout.sessions.create({mode:"payment",line_items:[{price:process.env.STRIPE_PRICE_ID,quantity:1}],success_url:`${process.env.PUBLIC_URL}/success.html`,cancel_url:`${process.env.PUBLIC_URL}/index.html#acquista`});res.json({url:s.url});}catch(e){res.status(500).json({error:"Checkout non configurato."});}});
app.listen(process.env.PORT||3000);